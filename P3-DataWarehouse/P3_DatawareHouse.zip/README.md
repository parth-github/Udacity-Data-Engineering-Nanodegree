
# Purpose of this database in context of the startup- Sparkify and their analytical goals.
The data warehouse is used to extract JSON format data available in AWS S3 for getting key insights by analytics team on songs play such as what songs their users are listening to. 


# Justification of database schema design and ETL pipeline
An ETL pipeline that extracts their data from S3, stages them in Redshift, and transforms data into a set of dimensional tables for their analytics team to continue finding insights into what songs their users are listening to.
# Example queries and results for song play analysis.
> select count(*) as total_user from dim_user

| total_user |
|------------|
|    105     |


> select count(*) as total_song from dim_song

| total_song |
|------------|
|   14896    |

> select count(*) as total_artist from dim_artist

| total_artist |
--------------
|    10025     |


> select count(*) as total_time from dim_time

| total_time |
------------
|    8023    |


> select count(*) as total_songplay from fact_songplay

| total_songplay |
|----------------|
|      326       |

> select count(*) as stag_event from staging_events

|stag_event
----------
8056


> select count(*) as stag_song from staging_songs

|stag_song
-------------
14896


# Steps:

1. Import all the necessary libraries
2. Write the configuration of AWS Cluster, store the important parameter in some other file
3. Configuration of boto3 which is an AWS SDK for Python
4. Using the bucket, can check whether files log files and song data files are present
5. Create an IAM User Role, Assign appropriate permissions and create the Redshift Cluster
6. Get the Value of Endpoint and Role for put into main configuration file
7. Authorize Security Access Group to Default TCP/IP Address
8. Launch database connectivity configuration
9. Go to Terminal write the command "python create_tables.py" and then "etl.py"
10. Should take around 4-10 minutes in total
11. Then you go back to jupyter notebook to test everything is working fine
12. I counted all the records in my tables
13. Now can delete the cluster, roles and assigned permission

# References:
- [Rubric Review](https://review.udacity.com/#!/rubrics/2501/view)